// MultiPostAI Poster — bridge content script
// (旧名: note-automation Poster。リブランド後も内部 source 文字列 "note-automation" は互換維持)
//
// MultiPostAI の Webアプリページに注入され、
// ページ ↔ 拡張 background 間を window.postMessage で中継する。
// これにより Webアプリ側は拡張IDを知らずに投稿リクエストを送れる。

(() => {
  if (window.__noteAutomationPosterBridgeLoaded) return;

  // manifest の content_scripts で localhost / 本番URL のみに限定済み。
  // ここの host チェックは多層防御（manifest が誤って広い match を持ってしまった場合の保険）。
  // 注: *.vercel.app は Chrome の Public Suffix List 制限で match patten として使えない。
  // プレビューURLを対象にしたい場合は manifest に個別追加する。
  const host = location.hostname;
  const isAllowed =
    host === "localhost" || host === "note-automation-rho.vercel.app";
  if (!isAllowed) return;

  const EXT_VERSION = chrome.runtime.getManifest().version;

  window.__noteAutomationPosterBridgeLoaded = true;

  // ページ → 拡張
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "note-automation") return;

    if (data.type === "POST_ARTICLE") {
      chrome.runtime.sendMessage(
        { type: "POST_ARTICLE", payload: data.payload },
        (result) => {
          window.postMessage(
            {
              source: "note-automation-poster-ext",
              type: "POST_ARTICLE_RESULT",
              requestId: data.requestId,
              result:
                result ?? {
                  ok: false,
                  error:
                    chrome.runtime.lastError?.message ?? "unknown bridge error",
                },
            },
            "*",
          );
        },
      );
    }

    // ページ → 拡張: 健康診断用 ping。応答に拡張バージョンも返す
    if (data.type === "PING") {
      window.postMessage(
        {
          source: "note-automation-poster-ext",
          type: "PONG",
          requestId: data.requestId,
          version: EXT_VERSION,
        },
        "*",
      );
    }

    // ページ → 拡張: 現在の note ログインアカウントを取得
    if (data.type === "GET_ACCOUNT") {
      chrome.runtime.sendMessage({ type: "GET_ACCOUNT" }, (result) => {
        window.postMessage(
          {
            source: "note-automation-poster-ext",
            type: "GET_ACCOUNT_RESULT",
            requestId: data.requestId,
            result:
              result ?? {
                ok: false,
                error:
                  chrome.runtime.lastError?.message ?? "unknown bridge error",
              },
          },
          "*",
        );
      });
    }
  });

  // 拡張インストール検知用の ready 通知
  window.postMessage(
    {
      source: "note-automation-poster-ext",
      type: "EXTENSION_READY",
      version: EXT_VERSION,
    },
    "*",
  );
})();
