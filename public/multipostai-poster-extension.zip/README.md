# MultiPostAI Poster (Chrome 拡張)

MultiPostAI で生成した記事を note.com に自動投稿するための内部 Chrome 拡張。

> 旧名: note-automation Poster。2026-05-27 に MultiPostAI へリブランド。
> 内部の通信プロトコル識別子は互換性維持のため `note-automation` を残置。

## 配布方針

- 社内特定メンバーのみが使用 (Chrome Web Store 公開なし)
- 開発者モードで「パッケージ化されていない拡張機能を読み込む」で導入

## インストール手順

1. Chrome のアドレスバーに `chrome://extensions` を開く
2. 右上の「デベロッパーモード」を ON
3. 「パッケージ化されていない拡張機能を読み込む」をクリック
4. このリポジトリの `extension/` フォルダを選択
5. note.com に普通にログインしておく

## 動作確認（単体テスト）

1. Chrome 右上のパズルアイコンから「MultiPostAI Poster」をピン留め
2. アイコンをクリックしてポップアップを開く
3. タイトルと本文を貼り付けて「投稿テスト」を押す
4. note.com の新規投稿ページが開いて、自動でフォームに入力される

## 現状の制約（初版）

- **下書き保存まで**。`publish:true` は未実装
- タグ・有料/無料・コメント可否・マガジン未対応
- アイキャッチ画像は MultiPostAI 本体の見出し画像のみ対応

## Webアプリ連携

MultiPostAI のライブラリ画面の「📝 noteへ投稿」ボタン or 商品スカウトの「✍ 記事生成」から直接呼び出せる。

仕組み:
- `bridge.js` が MultiPostAI の Web ページに content script として注入される
- Web アプリは `window.postMessage({ source: 'note-automation', type: 'POST_ARTICLE', ... })` で投稿リクエストを発射 (source 文字列は内部識別子のため `note-automation` のまま維持)
- bridge.js が拾って background に転送、結果も逆方向に返す
- ⇒ Web アプリ側は拡張IDを知らなくて良い

対応 URL (manifest の content_scripts に登録):
- `http://localhost:3000/*`
- `http://localhost:3010/*`
- `https://note-automation-rho.vercel.app/*`

**重要: 拡張を更新した後、Webアプリ側のタブも一度ハード再読込（Cmd+Shift+R）が必要**

## ファイル構成

| ファイル | 役割 |
| --- | --- |
| `manifest.json` | MV3 マニフェスト |
| `background.js` | ポップアップ/Webアプリからの指示を受け、note 投稿ページのタブを開いて content.js に渡す |
| `content.js` | note 投稿ページ上で DOM 操作してタイトル・本文・タグを入力 |
| `bridge.js` | MultiPostAI の Web ページに注入され、ページ ↔ background を window.postMessage で中継。`PING/PONG` で拡張インストール検知も担当 |
| `popup.html` / `popup.js` | 単体テスト用 UI |
