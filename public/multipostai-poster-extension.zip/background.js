// MultiPostAI Poster — background service worker
//
// 役割:
//   1) ポップアップ or Webアプリから「投稿してくれ」メッセージを受け取る
//   2) note.com の新規投稿ページを開く
//   3) そのタブの読み込みが完了したら content.js にペイロードを渡す
//   4) content.js から返ってきた結果（成功/失敗、公開URL）を呼び出し元に返す

const NEW_POST_URL = "https://note.com/notes/new"; // TODO: 実機で確認

// 現在 note.com にログイン中のアカウントを取得する。
// note の current_user API を拡張の host 権限 (= note.com の Cookie) 付きで叩く。
// 投稿はこのログインアカウントに対して行われるため、誤爆防止の表示に使う。
async function getCurrentNoteAccount() {
  try {
    const res = await fetch("https://note.com/api/v2/current_user", {
      credentials: "include",
      headers: { accept: "application/json" },
    });
    if (res.status === 401 || res.status === 403) {
      return { ok: false, loggedIn: false, error: "note.com に未ログインです" };
    }
    if (!res.ok) {
      return { ok: false, error: `note API エラー (${res.status})` };
    }
    const json = await res.json();
    // note のレスポンス形はバージョンで揺れるため防御的に拾う
    const u = json?.data?.user ?? json?.data ?? json?.user ?? json ?? {};
    const urlname = u.urlname || u.username || u.url_name || null;
    const nickname = u.nickname || u.name || u.display_name || null;
    if (!urlname && !nickname) {
      return { ok: false, loggedIn: false, error: "ログイン情報を取得できませんでした" };
    }
    return { ok: true, loggedIn: true, urlname, nickname };
  } catch (e) {
    return { ok: false, error: `取得失敗: ${e?.message ?? e}` };
  }
}

// 投稿中タブ → 投稿ペイロード を保持
/** @type {Map<number, { payload: any, sendResponse: (r:any)=>void }>} */
const pending = new Map();

async function writeLastResult(result) {
  try {
    await chrome.storage.local.set({
      lastResult: { ...result, ts: Date.now() },
    });
  } catch (e) {
    console.warn("storage write failed", e);
  }
}

function handlePostRequest(payload, sendResponse) {
  // 開始時点を記録（ポップアップが閉じても再オープンで状況がわかる）
  writeLastResult({
    ok: null,
    mode: "in_progress",
    publish: !!payload?.publish,
    title: payload?.title,
  });

  chrome.tabs.create({ url: NEW_POST_URL, active: true }, (tab) => {
    if (!tab || tab.id == null) {
      const r = { ok: false, error: "新規タブを開けませんでした" };
      writeLastResult(r);
      sendResponse(r);
      return;
    }
    pending.set(tab.id, { payload, sendResponse });
  });
}

// タブ読み込み完了を待って content.js にペイロードを送る
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== "complete") return;
  if (!pending.has(tabId)) return;
  if (!tab.url || !/^https:\/\/(editor\.)?note\.com\//.test(tab.url)) return;

  // 同じタブで onUpdated が複数回 "complete" を発火することがある（SPA navigation 等）。
  // sendMessage の応答コールバックを待たずに pending から即削除して二重送信を防ぐ。
  const entry = pending.get(tabId);
  pending.delete(tabId);

  chrome.tabs.sendMessage(
    tabId,
    { type: "FILL_AND_POST", payload: entry.payload },
    (result) => {
      let finalResult;
      if (chrome.runtime.lastError) {
        finalResult = {
          ok: false,
          error: `content.js 応答なし: ${chrome.runtime.lastError.message}`,
        };
      } else {
        finalResult = result ?? { ok: false, error: "空応答" };
      }
      writeLastResult(finalResult);
      try { entry.sendResponse(finalResult); } catch (_) {}
    },
  );
});

// content.js からのログ集約。chrome.storage に時系列で残し popup から閲覧する。
async function appendPosterLog(level, line) {
  try {
    const { posterLogs } = await chrome.storage.local.get("posterLogs");
    const arr = Array.isArray(posterLogs) ? posterLogs : [];
    arr.push({ ts: Date.now(), level: level ?? "log", line: String(line ?? "") });
    // 直近200件のみ保持
    const trimmed = arr.slice(-200);
    await chrome.storage.local.set({ posterLogs: trimmed });
  } catch (e) {
    console.warn("posterLogs write failed", e);
  }
}

// 内部メッセージ（ポップアップ / content から）
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "POST_ARTICLE") {
    handlePostRequest(msg.payload, sendResponse);
    return true; // async
  }
  if (msg?.type === "POSTER_LOG") {
    appendPosterLog(msg.level, msg.line);
    return; // fire-and-forget
  }
  if (msg?.type === "POSTER_LOGS_CLEAR") {
    chrome.storage.local.set({ posterLogs: [] }).then(() => sendResponse({ ok: true }));
    return true; // async
  }
  if (msg?.type === "GET_ACCOUNT") {
    getCurrentNoteAccount().then(sendResponse);
    return true; // async
  }
});

// 外部メッセージ（Webアプリから）
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "PING") {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return;
  }
  if (msg?.type === "POST_ARTICLE") {
    handlePostRequest(msg.payload, sendResponse);
    return true; // async
  }
  if (msg?.type === "GET_ACCOUNT") {
    getCurrentNoteAccount().then(sendResponse);
    return true; // async
  }
});
