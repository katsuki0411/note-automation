// MultiPostAI Poster — content script
//
// note.com の投稿ページ DOM を操作してタイトル・本文を入力する。
// 初版方針:
//   - 下書き保存まで（公開ボタンは押さない）。動作確認できたら publish:true で公開まで進めるよう拡張する。
//   - タグ・有料/無料・コメント可否・マガジンは未対応。後続コミットで足す。
//   - セレクタは note.com の DOM 変更に追従が必要。すべて TODO マーク済み。

(() => {
  if (window.__noteAutomationPosterLoaded) return;
  window.__noteAutomationPosterLoaded = true;

  let fillInFlight = false;
  let fillDone = false;

  // chrome.storage 経由でログを残す（事前に DevTools を開けないため、後でポップアップから確認）
  function plog(...args) {
    try { console.log("[note-poster]", ...args); } catch (_) {}
    try {
      const line = args
        .map((a) => {
          if (a == null) return String(a);
          if (typeof a === "string") return a;
          if (a instanceof Element) return `<${a.tagName.toLowerCase()}${a.id ? "#" + a.id : ""}>`;
          try { return JSON.stringify(a); } catch (_) { return String(a); }
        })
        .join(" ");
      chrome.runtime.sendMessage({ type: "POSTER_LOG", level: "log", line });
    } catch (_) {}
  }
  function pwarn(...args) {
    try { console.warn("[note-poster]", ...args); } catch (_) {}
    try {
      const line = args.map((a) => (typeof a === "string" ? a : a?.message ?? String(a))).join(" ");
      chrome.runtime.sendMessage({ type: "POSTER_LOG", level: "warn", line });
    } catch (_) {}
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type !== "FILL_AND_POST") return;

    // 同一ページに対する FILL_AND_POST は1回しか実行しない（背景側でも防いでいるが二重防御）
    if (fillDone) {
      sendResponse({ ok: true, mode: "draft", skipped: "already-filled" });
      return;
    }
    if (fillInFlight) {
      sendResponse({ ok: false, error: "fill in progress" });
      return;
    }
    fillInFlight = true;

    fillAndPost(msg.payload)
      .then((result) => {
        fillInFlight = false;
        if (result?.ok) fillDone = true;
        sendResponse(result);
      })
      .catch((err) => {
        fillInFlight = false;
        sendResponse({ ok: false, error: err?.message ?? String(err) });
      });
    return true; // async
  });

  async function fillAndPost(payload) {
    const { title, body, tags = [], publish = false, imageUrl } = payload ?? {};
    if (!title || !body) {
      return { ok: false, error: "title / body が空" };
    }

    // --- タイトル入力 ---
    const titleEl = await waitFor(
      // TODO: 実機の note 投稿ページで確認して差し替える
      'textarea[placeholder*="記事タイトル"], textarea[aria-label*="タイトル"], input[placeholder*="タイトル"]',
      8000,
    );
    if (!titleEl) return { ok: false, error: "タイトル入力欄が見つからない" };
    setNativeValue(titleEl, title);
    titleEl.dispatchEvent(new Event("input", { bubbles: true }));
    titleEl.dispatchEvent(new Event("change", { bubbles: true }));

    // --- 本文入力 ---
    // note は TipTap (ProseMirror) ベース。contenteditable に paste するのが確実。
    const editor = await waitFor(
      // TODO: 実機で確認して差し替える
      'div.ProseMirror, div[contenteditable="true"]',
      8000,
    );
    if (!editor) return { ok: false, error: "本文エディタが見つからない" };
    editor.focus();

    const dt = new DataTransfer();
    dt.setData("text/plain", body);
    editor.dispatchEvent(
      new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        clipboardData: dt,
      }),
    );

    // --- 見出し画像（アイキャッチ）アップロード ---
    if (imageUrl) {
      try {
        await uploadEyecatchImage(imageUrl);
      } catch (e) {
        // 画像セットの失敗は致命傷にせず、本文/タイトルは投稿継続
        pwarn("見出し画像のセットに失敗:", e);
      }
      // note は画像 drop 時に React state を再構築するため、
      // タイトル/本文の値がクリアされる現象を観測。
      // → 待機を長め + 2回リトライ で確実に値を保つ。
      await sleep(1500);
      try {
        await reinjectTitleAndBody(title, body);
        // 2 回目: note は2回 re-render するパターンを観測したので、念のためもう一度
        await sleep(800);
        await reinjectTitleAndBody(title, body);
      } catch (e) {
        pwarn("画像後の整合性チェック失敗:", e);
      }
    }

    // --- 公開 or 下書き ---
    if (!publish) {
      // 下書き保存は note 側で自動保存される想定
      return { ok: true, mode: "draft" };
    }

    // 本文反映が DOM に行き渡るまで少し待つ
    await sleep(500);

    // ★公開ボタンを押す直前の最終チェック: タイトル/本文が消えていないか
    try {
      await reinjectTitleAndBody(title, body);
    } catch (e) {
      pwarn("公開直前の整合性チェック失敗:", e);
    }

    // 1) エディタ画面右上の「公開」または「公開設定」ボタンを押す → モーダル起動
    const openModalBtn = await waitForButton(["公開設定", "公開に進む", "公開"], 8000);
    if (!openModalBtn) return { ok: false, error: "公開ボタンが見つからない" };
    openModalBtn.click();

    // 2) モーダル描画を待つ
    await sleep(800);

    // 3) タグ入力（あれば）
    if (tags.length > 0) {
      try {
        await fillTags(tags);
      } catch (e) {
        // タグ入力失敗は致命傷にせずログだけ残す
        pwarn("タグ入力に失敗:", e);
      }
    }

    // 4) 最終投稿ボタン
    const finalBtn = await waitForButton(["投稿する", "公開する", "投稿"], 8000);
    if (!finalBtn) return { ok: false, error: "最終投稿ボタンが見つからない" };

    // 3) sendResponse を先に返してから click する。
    //    note.com の公開遷移でこのページが bfcache に入りメッセージポートが閉じるため、
    //    click 前に応答を返却する。結果（公開済みURL等）は note のタブを見れば分かるので
    //    拡張側で追跡しない。
    setTimeout(() => finalBtn.click(), 200);
    return { ok: true, mode: "publish_clicked" };
  }

  // --- helpers ---

  // タイトル/本文を毎回 querySelector で取り直して、消えていれば再注入する。
  // 画像 drop 後の React re-render で React state が空にリセットされるケースの吸収用。
  async function reinjectTitleAndBody(title, body) {
    // ★タイトル
    const titleEl = document.querySelector(
      'textarea[placeholder*="記事タイトル"], textarea[aria-label*="タイトル"], input[placeholder*="タイトル"]',
    );
    if (!titleEl) {
      pwarn("reinject: タイトル要素が見つからない");
    } else {
      const titleNow = (titleEl.value ?? "").trim();
      if (titleNow !== title.trim()) {
        plog("タイトル再入力:", `"${titleNow.slice(0, 30)}" -> "${title.slice(0, 30)}..."`);
        await injectTextIntoInput(titleEl, title);
        // 確認
        await sleep(150);
        const after = (titleEl.value ?? "").trim();
        if (after !== title.trim()) {
          pwarn("タイトル再入力後も不一致:", `"${after.slice(0, 30)}"`);
        } else {
          plog("タイトル再入力 成功");
        }
      } else {
        plog("タイトル保持OK:", `"${titleNow.slice(0, 30)}"`);
      }
    }
    // ★本文
    const editorEl = document.querySelector('div.ProseMirror, div[contenteditable="true"]');
    if (!editorEl) {
      pwarn("reinject: 本文要素が見つからない");
    } else {
      const bodyText = (editorEl.textContent || "").trim();
      if (bodyText.length < Math.min(200, body.length / 3)) {
        plog("本文再入力 現:", bodyText.length, "文字");
        editorEl.focus();
        const dt2 = new DataTransfer();
        dt2.setData("text/plain", body);
        editorEl.dispatchEvent(
          new ClipboardEvent("paste", {
            bubbles: true,
            cancelable: true,
            clipboardData: dt2,
          }),
        );
        await sleep(400);
      } else {
        plog("本文保持OK:", bodyText.length, "文字");
      }
    }
  }

  // textarea/input への確実な値挿入。
  // setNativeValue だけでは React state に伝わらない note の TextField 用に
  // execCommand('insertText') もフォールバックで併用する。
  async function injectTextIntoInput(el, value) {
    el.focus();
    // 1) 既存値をクリア
    try {
      el.select?.();
      el.setSelectionRange?.(0, (el.value ?? "").length);
      document.execCommand("delete", false);
    } catch (_) {}
    // 2) execCommand で挿入（React/Vue/etc の onChange を確実に発火させる）
    let ok = false;
    try {
      ok = document.execCommand("insertText", false, value);
    } catch (_) {}
    // 3) execCommand が効かなかったら setNativeValue フォールバック
    if (!ok || el.value !== value) {
      setNativeValue(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  // 見出し画像をアップロードする。
  // note のアイキャッチ UI（2026-05 時点）:
  //   1) タイトル左上の <button aria-label="画像を追加"> （+カメラアイコン）を押す
  //   2) モーダル展開 → 「画像をアップロード / 記事にあう画像を選ぶ / Adobe Express」
  //   3) 「画像をアップロード」をクリック → ネイティブのファイル選択ダイアログが出る
  //
  // 課題: モーダル内に hidden file input が存在せず、クリック時に動的生成 → 直接 inject 不可。
  //
  // 戦略: drop イベントを画像エリアに dispatch して React 側のドロップハンドラを発火させる。
  //       これで note のアップロードフローを擬似的に呼び出せる。
  async function uploadEyecatchImage(imageUrl) {
    plog("画像アップロード開始:", imageUrl);
    const resp = await fetch(imageUrl, { mode: "cors" });
    if (!resp.ok) throw new Error(`画像取得失敗: HTTP ${resp.status}`);
    const blob = await resp.blob();
    const filename = `eyecatch-${Date.now()}.png`;
    const file = new File([blob], filename, {
      type: blob.type || "image/png",
    });
    plog("File化完了:", file.size, "bytes");

    // 既に見出し画像が入っていたら何もしない（× ボタンが存在する=入力済）
    if (isEyecatchAlreadySet()) {
      plog("見出し画像は既に設定済み、スキップ");
      return;
    }

    const trigger = findEyecatchTrigger();
    if (!trigger) {
      throw new Error("見出し画像追加ボタン(aria-label='画像を追加')が見つからない");
    }
    plog("trigger発見:", trigger.getAttribute("aria-label"));

    // トリミング/確定モーダルが出ていれば押すヘルパー
    const confirmCrop = async () => {
      const btn = await waitForButton(
        ["この画像にする", "保存", "適用", "完了", "決定"],
        3000,
      );
      if (btn) {
        plog("確定ボタンクリック:", btn.innerText);
        btn.click();
        await sleep(600);
      }
    };

    // ===== 方式B: ファイル選択インターセプト (eyecatch-inject.js / MAIN world) =====
    // note の「画像をアップロード」→ 内部の input.click() を横取りして File を注入する。
    let injected = false;
    const onMsg = (e) => {
      if (e.source === window && e.data?.__mpaEyecatch === "injected") injected = true;
    };
    window.addEventListener("message", onMsg);
    try {
      window.postMessage({ __mpaEyecatch: "arm", file }, "*");
      plog("インターセプタを arm");

      trigger.click(); // アイキャッチモーダルを開く
      await sleep(450);
      const uploadBtn = await waitForButton(
        ["画像をアップロード", "アップロード"],
        3000,
      );
      if (uploadBtn) {
        plog("「画像をアップロード」クリック → input.click を横取り");
        uploadBtn.click();
        for (let i = 0; i < 25 && !injected; i++) await sleep(100);
      } else {
        plog("「画像をアップロード」ボタンが見つからない（モーダル構造変化？）");
      }
      if (injected) {
        plog("File 注入成功。note のアップロード処理を待機");
        await sleep(2500);
      }
    } finally {
      window.postMessage({ __mpaEyecatch: "disarm" }, "*");
      window.removeEventListener("message", onMsg);
    }

    if (isEyecatchAlreadySet()) {
      plog("見出し画像セット成功（インターセプト経由）");
      await confirmCrop();
      return;
    }

    // ===== フォールバック: 旧 drag-drop（note が合成イベントを受ければ稀に通る） =====
    plog("インターセプト不発。drag-drop フォールバックを試行");
    const dropArea = findDropArea(trigger);
    for (const type of ["dragenter", "dragover", "drop"]) {
      const dt = new DataTransfer();
      dt.items.add(file);
      dropArea.dispatchEvent(
        new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt }),
      );
      await sleep(50);
    }
    await sleep(2500);

    if (isEyecatchAlreadySet()) {
      plog("見出し画像セット成功（drag-drop経由）");
      await confirmCrop();
    } else {
      // どちらも不発 → 手動運用に倒す（エラー欄は汚さない）
      plog("自動セット不発（インターセプト/DnDとも不可）。手動運用を推奨");
    }
  }

  // 見出し画像が既に設定されているかを判定。
  // 「画像を追加」aria-label の button が消えていれば設定済みと判断。
  function isEyecatchAlreadySet() {
    const trigger = document.querySelector('button[aria-label="画像を追加"]');
    return !trigger || !isVisible(trigger);
  }

  // 見出し画像追加ボタンを厳密に見つける。
  // 厳密に aria-label="画像を追加" のみマッチ（「画像の配置」などの誤ヒット防止）。
  function findEyecatchTrigger() {
    const candidates = document.querySelectorAll('button[aria-label="画像を追加"]');
    for (const el of candidates) {
      if (isVisible(el)) return el;
    }
    return null;
  }

  // trigger の祖先で「ドロップ受け入れエリア」を返す。
  // note のDnDラッパーは data-dragging 属性を持つので、それを最優先。
  function findDropArea(trigger) {
    const dragContainer = trigger.closest("[data-dragging]");
    if (dragContainer) return dragContainer;
    // フォールバック: 大きめのラッパー要素
    let el = trigger;
    for (let i = 0; i < 6 && el; i++) {
      const r = el.getBoundingClientRect();
      if (r.width >= 200 && r.height >= 100) return el;
      el = el.parentElement;
    }
    return trigger.parentElement || trigger;
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function isVisible(el) {
    if (!el) return false;
    if (el.disabled) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    const style = getComputedStyle(el);
    if (style.visibility === "hidden" || style.display === "none") return false;
    return true;
  }

  // テキスト一致のボタンを表示中・有効なものに限って探す（モーダル描画を待つためポーリング）
  async function waitForButton(textCandidates, timeoutMs) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const all = document.querySelectorAll('button, [role="button"], a');
      for (const el of all) {
        if (!isVisible(el)) continue;
        const t = (el.innerText || el.textContent || "").trim();
        if (!t) continue;
        if (textCandidates.some((needle) => t === needle)) return el;
      }
      // 完全一致がなければ部分一致でフォールバック
      for (const el of all) {
        if (!isVisible(el)) continue;
        const t = (el.innerText || el.textContent || "").trim();
        if (!t) continue;
        if (textCandidates.some((needle) => t.includes(needle))) return el;
      }
      await sleep(200);
    }
    return null;
  }

  // モーダル内のタグ入力欄に1個ずつタグを入れる。
  // note の挙動: 入力 → Enter で確定（チップ化）。確定機構がEnter以外なら要修正。
  async function fillTags(tags) {
    const tagInput = await waitFor(
      // TODO: 実機の note 公開モーダルで確認
      'input[placeholder*="タグ"], input[aria-label*="タグ"], input[name*="tag"]',
      5000,
    );
    if (!tagInput) {
      pwarn("タグ入力欄が見つからない、スキップ");
      return;
    }
    tagInput.focus();
    for (const tag of tags) {
      const t = String(tag).trim();
      if (!t) continue;
      setNativeValue(tagInput, t);
      tagInput.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(150);
      for (const type of ["keydown", "keypress", "keyup"]) {
        tagInput.dispatchEvent(
          new KeyboardEvent(type, {
            key: "Enter",
            code: "Enter",
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true,
          }),
        );
      }
      await sleep(250);
    }
  }

  function waitFor(selector, timeoutMs) {
    return new Promise((resolve) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);

      const observer = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) {
          observer.disconnect();
          resolve(found);
        }
      });
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }

  // React/Vue 等が監視する value setter を経由して値を入れる
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
  }
})();
