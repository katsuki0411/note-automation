// MultiPostAI Poster — MAIN world file-input interceptor (見出し画像 自動セット用)
//
// note の「画像をアップロード」は、内部で <input type="file"> を動的生成して
// .click() を呼び、OS のファイル選択ダイアログを開く。
// このスクリプトはページ(MAIN world)に注入され、armされている間は file input の
// プログラム的 .click() を横取りし、ダイアログを出さずに指定Fileを注入する。
// これにより Blob の見出し画像を「ユーザーが選んだ」のと同じ形で note に渡せる。
//
// content.js(隔離world)とは window.postMessage で連携:
//   - {__mpaEyecatch:"arm", file}    … File を受け取り横取りをON
//   - {__mpaEyecatch:"disarm"}        … 横取りをOFF
//   - 注入したら {__mpaEyecatch:"injected"} を返す / 失敗は {__mpaEyecatch:"error"}
(() => {
  if (window.__mpaEyecatchInjectLoaded) return;
  window.__mpaEyecatchInjectLoaded = true;

  let pendingFile = null;

  window.addEventListener("message", (e) => {
    if (e.source !== window || !e.data) return;
    const d = e.data;
    if (d.__mpaEyecatch === "arm" && d.file) {
      pendingFile = d.file;
    } else if (d.__mpaEyecatch === "disarm") {
      pendingFile = null;
    }
  });

  const nativeClick = HTMLInputElement.prototype.click;
  HTMLInputElement.prototype.click = function () {
    if (pendingFile && this.type === "file") {
      const f = pendingFile;
      pendingFile = null; // 1回だけ
      try {
        const dt = new DataTransfer();
        dt.items.add(f);
        this.files = dt.files;
        this.dispatchEvent(new Event("input", { bubbles: true }));
        this.dispatchEvent(new Event("change", { bubbles: true }));
        window.postMessage({ __mpaEyecatch: "injected" }, "*");
        return; // ネイティブダイアログは開かない
      } catch (err) {
        window.postMessage(
          { __mpaEyecatch: "error", error: String((err && err.message) || err) },
          "*",
        );
      }
    }
    return nativeClick.apply(this, arguments);
  };
})();
